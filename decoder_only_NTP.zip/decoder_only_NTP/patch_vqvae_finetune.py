"""
Patch-based VQVAE + Transformer 微调脚本
使用 MSE 损失进行时间序列预测
"""

import numpy as np
import pandas as pd
import os
import sys
import json
import torch
from torch import nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.cuda import amp
import argparse
from pathlib import Path
from datetime import datetime
import time

# 添加根目录到 path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from src.models.patch_vqvae_transformer import PatchVQVAETransformer
from src.models.layers.revin import RevIN
from src.basics import set_device
from datautils import get_dls


def parse_args():
    parser = argparse.ArgumentParser(description='Patch VQVAE Transformer 微调')
    
    # 数据集参数
    parser.add_argument('--dset', type=str, default='ettm1', help='数据集名称')
    parser.add_argument('--context_points', type=int, default=512, help='输入序列长度')
    parser.add_argument('--target_points', type=int, default=96, help='预测长度')
    parser.add_argument('--batch_size', type=int, default=64, help='批次大小')
    parser.add_argument('--num_workers', type=int, default=0, help='数据加载线程数')
    parser.add_argument('--scaler', type=str, default='standard', help='数据缩放方式')
    parser.add_argument('--features', type=str, default='M', help='特征类型')
    
    # 预训练模型参数
    parser.add_argument('--pretrained_model', type=str, required=True, help='预训练模型路径')
    
    # 训练参数
    parser.add_argument('--n_epochs', type=int, default=50, help='训练轮数')
    parser.add_argument('--lr', type=float, default=1e-4, help='学习率')
    parser.add_argument('--weight_decay', type=float, default=1e-4, help='权重衰减')
    parser.add_argument('--revin', type=int, default=1, help='是否使用RevIN')
    parser.add_argument('--amp', type=int, default=1, help='是否启用混合精度')
    parser.add_argument('--run_id', type=int, default=None, help='运行ID（用于多次运行同一参数组合）')
    
    # Gumbel-Softmax参数（微调阶段的码本查找）
    parser.add_argument('--use_gumbel_softmax', type=int, default=1, help='是否使用Gumbel-Softmax（1启用，0使用普通Softmax）')
    parser.add_argument('--gumbel_temperature', type=float, default=1.0, help='Gumbel-Softmax温度（越小越接近argmax）')
    parser.add_argument('--gumbel_hard', type=int, default=0, help='是否使用Straight-Through Gumbel（前向硬采样，反向软梯度）')
    
    # 自回归预测参数
    parser.add_argument('--ar_step_size', type=int, default=None, help='自回归步长（每步预测的patch数）。None表示非自回归（一次预测所有）')
    
    # 保存参数
    parser.add_argument('--save_path', type=str, default='saved_models/patch_vqvae_finetune/', help='模型保存路径')
    parser.add_argument('--model_id', type=int, default=1, help='模型ID')
    
    return parser.parse_args()


def load_pretrained_model(checkpoint_path, device, n_channels=None, args=None):
    """加载预训练模型
    
    Args:
        checkpoint_path: checkpoint路径
        device: 设备
        n_channels: 通道数（未使用，保留以兼容旧代码）
        args: 命令行参数（用于Gumbel-Softmax配置）
    
    Returns:
        model: 加载的模型
        config: 模型配置
        pretrain_args: 预训练时的参数（用于获取step_size等）
    """
    print(f'加载预训练模型: {checkpoint_path}')
    # PyTorch 2.6+ 兼容性：设置 weights_only=False 以支持包含 numpy 对象的 checkpoint
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    
    config = checkpoint['config']
    state_dict = checkpoint['model_state_dict']
    pretrain_args = checkpoint.get('args', {})  # 获取预训练时的参数
    
    # 添加Gumbel-Softmax配置（微调阶段的码本查找）
    if args is not None:
        config['use_gumbel_softmax'] = bool(getattr(args, 'use_gumbel_softmax', 1))
        config['gumbel_temperature'] = getattr(args, 'gumbel_temperature', 1.0)
        config['gumbel_hard'] = bool(getattr(args, 'gumbel_hard', 0))
        print(f'Gumbel-Softmax配置: use={config["use_gumbel_softmax"]}, temp={config["gumbel_temperature"]}, hard={config["gumbel_hard"]}')
    
    # 创建模型
    model = PatchVQVAETransformer(config).to(device)
    
    # 直接加载所有权重，使用strict=False允许架构差异
    model.load_state_dict(state_dict, strict=False)
    
    print(f'预训练模型配置: {config}')
    print(f'预训练验证损失: {checkpoint.get("val_loss", "N/A")}')
    
    # 打印预训练时的step_size（如果存在）
    if 'progressive_step_size' in pretrain_args:
        print(f'预训练step_size: {pretrain_args["progressive_step_size"]}')
    
    return model, config, pretrain_args


def freeze_encoder_vq(model, freeze_patch_attention=True):
    """冻结encoder、decoder、VQ层（将patch映射成码本前的所有参数）"""
    # 使用模型的方法冻结VQVAE组件
    model.freeze_vqvae(components=['Encoder', 'Decoder', 'VQ'])


def train_batch(model, batch_x, batch_y, optimizer, revin, args, device, scaler):
    """训练一个batch"""
    batch_x = batch_x.to(device)  # [B, context_points, C]
    batch_y = batch_y.to(device)  # [B, target_points, C]
    
    # RevIN归一化
    if revin:
        batch_x = revin(batch_x, 'norm')
    
    with amp.autocast(enabled=scaler.is_enabled()):
        # 前向传播: 预测码本索引 -> 解码（支持自回归步长）
        pred, _ = model.forward_finetune(batch_x, args.target_points, step_size=args.ar_step_size)
        
        # RevIN反归一化
        if revin:
            pred = revin(pred, 'denorm')
        
        # 用于反向传播和报告的loss（使用mean）
        loss = F.mse_loss(pred, batch_y, reduction='mean')
    
    # 反向传播（只对可训练参数）
    optimizer.zero_grad()
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    # 只对可训练参数进行梯度裁剪
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    torch.nn.utils.clip_grad_norm_(trainable_params, max_norm=1.0)
    scaler.step(optimizer)
    scaler.update()
    
    return loss.item()


def validate_epoch(model, dataloader, revin, args, device, use_amp):
    """验证一个epoch"""
    model.eval()
    total_loss = 0
    n_batches = 0
    
    with torch.no_grad():
        for batch_x, batch_y in dataloader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            
            if revin:
                batch_x = revin(batch_x, 'norm')
            
            with amp.autocast(enabled=use_amp):
                pred, _ = model.forward_finetune(batch_x, args.target_points, step_size=args.ar_step_size)
            
            if revin:
                pred = revin(pred, 'denorm')
            
            # 使用mean
            mse_loss = F.mse_loss(pred, batch_y, reduction='mean')
            total_loss += mse_loss.item()
            n_batches += 1
    
    # 按batch数平均
    return total_loss / n_batches if n_batches > 0 else 0.0


def test_model(model, dataloader, revin, args, device, use_amp):
    """测试模型"""
    model.eval()
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for batch_x, batch_y in dataloader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            
            if revin:
                batch_x = revin(batch_x, 'norm')
            
            with amp.autocast(enabled=use_amp):
                pred, _ = model.forward_finetune(batch_x, args.target_points, step_size=args.ar_step_size)
            
            # 验证预测长度与目标长度一致
            assert pred.shape[1] == batch_y.shape[1] == args.target_points, \
                f"预测长度 {pred.shape[1]} 与目标长度 {batch_y.shape[1]} 或 args.target_points {args.target_points} 不匹配"
            
            if revin:
                pred = revin(pred, 'denorm')
            
            all_preds.append(pred.cpu())
            all_targets.append(batch_y.cpu())
    
    preds = torch.cat(all_preds, dim=0).numpy()
    targets = torch.cat(all_targets, dim=0).numpy()
    
    mse = np.mean((preds - targets) ** 2)
    mae = np.mean(np.abs(preds - targets))
    
    return mse, mae, preds, targets


def main():
    args = parse_args()
    print('Args:', args)
    
    # PyTorch 2.7+ 兼容性修复：禁用 flash attention 和 memory-efficient attention
    # 当使用 mask 时，这些优化可能导致 CUDA 错误
    if torch.cuda.is_available():
        if hasattr(torch.backends.cuda, 'enable_flash_sdp'):
            torch.backends.cuda.enable_flash_sdp(False)
        if hasattr(torch.backends.cuda, 'enable_mem_efficient_sdp'):
            torch.backends.cuda.enable_mem_efficient_sdp(False)
        if hasattr(torch.backends.cuda, 'enable_math_sdp'):
            torch.backends.cuda.enable_math_sdp(True)
        print('✓ 已禁用 flash/memory-efficient attention（PyTorch 2.7+ 兼容性修复）')
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if device.type == 'cuda':
        torch.set_float32_matmul_precision('medium')
    
    # 创建保存目录
    save_dir = Path(args.save_path) / args.dset
    save_dir.mkdir(parents=True, exist_ok=True)
    
    # 先获取数据
    args.dset_finetune = args.dset
    dls = get_dls(args)
    print(f'Number of channels: {dls.vars}')
    print(f'Train batches: {len(dls.train)}, Valid batches: {len(dls.valid)}, Test batches: {len(dls.test)}')
    
    # 加载预训练模型（传入args以配置Gumbel-Softmax）
    model, config, pretrain_args = load_pretrained_model(args.pretrained_model, device, n_channels=dls.vars, args=args)
    
    # 自动继承预训练的step_size（如果finetune时未指定ar_step_size）
    if args.ar_step_size is None and 'progressive_step_size' in pretrain_args:
        args.ar_step_size = pretrain_args['progressive_step_size']
        print(f'✓ 自动继承预训练step_size: {args.ar_step_size}')
    
    # 冻结 encoder、VQ 层（将patch映射成码本前的所有参数）
    freeze_encoder_vq(model)
    
    # 打印可训练参数
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    frozen_params = total_params - trainable_params
    
    print(f'\n模型参数统计:')
    print(f'  总参数: {total_params:,}')
    print(f'  可训练参数: {trainable_params:,}')
    print(f'  冻结参数: {frozen_params:,}')
    
    # AMP
    use_amp = bool(args.amp) and device.type == 'cuda'
    scaler = amp.GradScaler(enabled=use_amp)
    print(f'AMP enabled: {use_amp}')
    
    # RevIN
    revin = RevIN(dls.vars, eps=1e-5, affine=False).to(device) if args.revin else None
    
    # 模型文件名
    # 如果提供了 run_id，则使用它；否则尝试从预训练模型路径中提取
    run_id = args.run_id
    if run_id is None:
        # 尝试从预训练模型路径中提取 run_id
        import re
        pretrained_model_name = Path(args.pretrained_model).stem
        match = re.search(r'_run(\d+)_', pretrained_model_name)
        if match:
            run_id = int(match.group(1))
    
    if run_id is not None:
        model_name = f'patch_vqvae_finetune_cw{args.context_points}_tw{args.target_points}_run{run_id}_model{args.model_id}'
    else:
        model_name = f'patch_vqvae_finetune_cw{args.context_points}_tw{args.target_points}_model{args.model_id}'
    
    # 优化器和调度器
    optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), 
                      lr=args.lr, weight_decay=args.weight_decay)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.n_epochs, eta_min=1e-6)
    
    # 训练
    best_val_loss = float('inf')
    train_losses, valid_losses = [], []
    no_improve_epochs = 0  # 连续无改善的epoch数
    early_stop_patience = 5  # 连续5个epoch无下降就停止
    best_epoch = -1  # 最佳模型所在的epoch
    
    start_time = time.time()
    
    print(f'\n开始微调，共 {args.n_epochs} 个 epoch')
    print(f'早停: 连续 {early_stop_patience} 个 epoch 无改善则停止')
    print('=' * 80)
    
    for epoch in range(args.n_epochs):
        model.train()
        epoch_train_losses = []
        
        # 训练一个epoch
        for batch_x, batch_y in dls.train:
            loss = train_batch(model, batch_x, batch_y, optimizer, revin, args, device, scaler)
            epoch_train_losses.append(loss)
        
        # Epoch结束，更新学习率
        scheduler.step()
        
        # 计算平均训练loss
        avg_train_loss = np.mean(epoch_train_losses)
        
        # 验证评估
        val_loss = validate_epoch(model, dls.valid, revin, args, device, use_amp)
        
        train_losses.append(avg_train_loss)
        valid_losses.append(val_loss)
        
        total_time = time.time() - start_time
        
        # 检查当前epoch是否改善了最佳验证损失
        is_best = val_loss < best_val_loss
        if is_best:
            best_val_loss = val_loss
            best_epoch = epoch
            no_improve_epochs = 0  # 重置计数器
            
            # 保存最佳模型
            checkpoint = {
                'model_state_dict': model.state_dict(),
                'config': config,
                'args': vars(args),
                'epoch': epoch,
                'train_loss': avg_train_loss,
                'val_loss': val_loss,
                'timestamp': datetime.now().isoformat(),
                'total_training_time_seconds': total_time,
            }
            torch.save(checkpoint, save_dir / f'{model_name}.pth')
            status = "*Best*"
        else:
            no_improve_epochs += 1
            status = ""
        
        # 打印进度
        print(f"Epoch {epoch+1:3d}/{args.n_epochs} | "
              f"Train Loss: {avg_train_loss:.6f} | Valid Loss: {val_loss:.6f} | "
              f"Time: {total_time/60:.1f}min {status}")
        
        if not is_best:
            print(f"  -> 无改善 (当前最佳: epoch {best_epoch+1}, val_loss: {best_val_loss:.6f}, "
                  f"连续 {no_improve_epochs} 个epoch无改善)")
        
        # 早停检查：连续10个epoch无改善
        if no_improve_epochs >= early_stop_patience:
            print(f"\n>>> 早停: 连续 {early_stop_patience} 个 epoch 无改善")
            # 保存当前模型（10个epoch无改善时的模型）
            checkpoint = {
                'model_state_dict': model.state_dict(),
                'config': config,
                'args': vars(args),
                'epoch': epoch,
                'train_loss': avg_train_loss,
                'val_loss': val_loss,
                'timestamp': datetime.now().isoformat(),
                'total_training_time_seconds': total_time,
                'early_stopped': True,
            }
            final_model_name = f'{model_name}_final_epoch{epoch+1}.pth'
            torch.save(checkpoint, save_dir / final_model_name)
            print(f"  -> 最终模型已保存: {final_model_name}")
            break
    
    # 测试
    print('\n' + '=' * 80)
    print('测试最佳模型...')
    
    # 加载最佳模型
    # PyTorch 2.6+ 兼容性：设置 weights_only=False 以支持包含 numpy 对象的 checkpoint
    best_checkpoint = torch.load(save_dir / f'{model_name}.pth', map_location=device, weights_only=False)
    model.load_state_dict(best_checkpoint['model_state_dict'])
    
    mse, mae, preds, targets = test_model(model, dls.test, revin, args, device, use_amp)
    print(f'测试结果: MSE = {mse:.6f}, MAE = {mae:.6f}')
    
    # 保存结果
    results_df = pd.DataFrame({
        'metric': ['MSE', 'MAE'],
        'value': [mse, mae]
    })
    results_df.to_csv(save_dir / f'{model_name}_results.csv', index=False)
    
    # 保存训练历史 (基于epoch)
    history_df = pd.DataFrame({
        'epoch': range(1, len(train_losses) + 1),
        'train_loss': train_losses,
        'valid_loss': valid_losses,
    })
    history_df.to_csv(save_dir / f'{model_name}_history.csv', index=False)
    
    print('=' * 80)
    print(f'微调完成！')
    print(f'最佳验证损失: {best_val_loss:.6f}')
    print(f'测试 MSE: {mse:.6f}, MAE: {mae:.6f}')
    print(f'模型保存至: {save_dir / model_name}.pth')


if __name__ == '__main__':
    set_device()
    main()
